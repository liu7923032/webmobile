<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script lang="babel">
 
</script>

<style lang="less">
@import '~vux/src/styles/reset';

body {
  background-color: #fbf9fe;
}
</style>

