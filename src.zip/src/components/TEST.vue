<template>  
    <div>我的测试啊</div>

    <cell :title="啊哈哈哈"></cell>
</template>

<script>
    import Cell from 'vux/src/components/group'
    export default {
        data () {
            return {

            }
        },
        components:{
            Cell
        }
    }
</script>