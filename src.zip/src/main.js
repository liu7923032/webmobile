import Vue from 'vue'
import App from './App'
import Home from './components/HelloFromVux'
import TEST from './components/TEST'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const router = new VueRouter()

router.map({
  '/': {
    component: Home
  },
  "test":{
    component:TEST
  }
})

router.start(App, '#app')

